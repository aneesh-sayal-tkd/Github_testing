import requests
import json
import time
from airflow.hooks.base import BaseHook


def get_token_value(databricks_conn_id):
    """
    Retrieves the token value for the given Databricks connection ID.

    Parameters:
        - databricks_conn_id (str): Databricks connection ID.

    Returns:
        - str: The token value.

    Raises:
        - RuntimeError: If token retrieval fails.
    """
    try:
        conn = BaseHook.get_connection(databricks_conn_id)
        if not conn.password:
            raise ValueError(f"No token found in connection {databricks_conn_id}")
        return conn.password
    except Exception as e:
        raise RuntimeError(f"Failed to retrieve token for connection {databricks_conn_id}: {e}")


def get_cluster_state(databricks_instance, cluster_id, token):
    """
    Retrieves the state of the Databricks cluster.

    Parameters:
        - databricks_instance (str): Databricks server hostname.
        - cluster_id (str): The cluster ID.
        - token (str): Authentication token.

    Returns:
        - str: The cluster state.

    Raises:
        - RuntimeError: If the request fails.
    """
    try:
        url = f"{databricks_instance}/api/2.0/clusters/get"
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        data = {'cluster_id': cluster_id}

        response = requests.get(url, headers=headers, data=json.dumps(data))
        if response.status_code == 200:
            state = response.json().get('state')
            state_message = response.json().get('state_message')
            print(f"Cluster state: {state} ({state_message})")
            return state
        else:
            raise RuntimeError(f"Failed to get cluster state: {response.text}. Status code: {response.status_code}")
    except Exception as e:
        raise e


def create_databricks_cluster(databricks_instance: str,
                              databricks_conn_id: str,
                              cluster_config: dict):
    """
    Creates a Databricks cluster using the provided configuration and waits until the cluster starts.

    Parameters:
        - databricks_instance (str): The hostname of the Databricks server.
        - databricks_conn_id (str): The connection ID for Databricks.
        - cluster_config (dict): A dictionary containing the cluster configuration.

    Returns:
        - str: The ID of the Databricks cluster when it is running.

    Raises:
        - RuntimeError: If cluster creation fails.
        - Exception: For any other errors during the process.
    """
    try:
        # Start time for performance measurement
        start_time = time.perf_counter()

        # Prepare API endpoint and headers
        url = f"{databricks_instance}/api/2.0/clusters/create"
        token = get_token_value(databricks_conn_id)
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        # Ensure the cluster configuration is already in dictionary form
        if isinstance(cluster_config, str):
            try:
                cluster_config = eval(cluster_config)  # Safer alternative to eval()
            except json.JSONDecodeError as e:
                raise ValueError("Invalid cluster configuration format") from e

        # Send POST request to create the cluster
        response = requests.post(url, headers=headers, json=cluster_config)

        # Handle response
        if response.status_code == 200:
            cluster_id = response.json().get("cluster_id")
            print(f"Cluster with ID: {cluster_id} created successfully! Waiting for cluster to start.")

            # Wait for the cluster to reach RUNNING state
            while True:
                state = get_cluster_state(databricks_instance, cluster_id, token)
                if state == "RUNNING":
                    # Calculate elapsed time
                    elapsed_time = time.perf_counter() - start_time
                    hours, remainder = divmod(elapsed_time, 3600)
                    minutes, seconds = divmod(remainder, 60)
                    print(f"Cluster is running. Time taken: {int(hours):02}:{int(minutes):02}:{int(seconds):02}")
                    return cluster_id
                elif state in ["TERMINATING", "TERMINATED", "ERROR"]:
                    raise RuntimeError(f"Cluster creation failed. Current state: {state}")
                else:
                    print(f"Cluster is in {state}. Waiting for it to start...")
                    time.sleep(10)  # Wait for 10 seconds before checking again
        else:
            raise RuntimeError(f"Cluster creation failed: {response.text}. Status code: {response.status_code}")
    except Exception as e:
        print("An error occurred during cluster creation:", e)
        raise


def start_cluster(databricks_instance, databricks_conn_id, cluster_id=None, cluster_config=None):
    """
    Starts a Databricks cluster if not running.

    Parameters:
        - databricks_instance (str): Databricks server hostname.
        - databricks_conn_id (str): Databricks connection ID.
        - cluster_id (Optional[str]): Existing cluster ID.
        - cluster_config (Optional[dict]): Cluster configuration.

    Returns:
        - Optional[str]: The cluster ID.
    """
    try:
        if cluster_id is None and cluster_config is not None:
            cluster_id = create_databricks_cluster(databricks_instance, databricks_conn_id, cluster_config)
        token = get_token_value(databricks_conn_id)
        state = get_cluster_state(databricks_instance, cluster_id, token)
        if state == "RUNNING":
            print("Cluster is already running.")
            return cluster_id
        elif state in ["TERMINATED", "ERROR", "PENDING"]:
            print(f"Cluster is in {state}. Attempting to start it...")
            url = f"{databricks_instance}/api/2.0/clusters/start"
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }
            data = {'cluster_id': cluster_id}
            response = requests.post(url, headers=headers, data=json.dumps(data))
            if response.status_code == 200:
                print("Cluster started successfully.")
            else:
                print(f"Failed to start cluster: {response.text}")
            return cluster_id
        else:
            print(f"Cluster state is {state}, unable to start cluster.")
            return cluster_id
    except Exception as e:
        raise e


def stop_cluster(databricks_instance, databricks_conn_id, cluster_id):
    """
    Stops a Databricks cluster.

    Parameters:
        - databricks_instance (str): Databricks server hostname.
        - databricks_conn_id (str): Databricks connection ID.
        - cluster_id (str): The cluster ID.

    Returns:
        - None
    """
    try:
        token = get_token_value(databricks_conn_id)
        state = get_cluster_state(databricks_instance, cluster_id, token)
        if state == "TERMINATED":
            print("Cluster is already terminated.")
            return
        print(f"Cluster is in {state}. Terminating...")
        url = f"{databricks_instance}/api/2.0/clusters/delete"
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        data = {'cluster_id': cluster_id}
        response = requests.post(url, headers=headers, data=json.dumps(data))
        if response.status_code == 200:
            print("Cluster stopped successfully.")
        else:
            print(f"Failed to stop cluster: {response.text}")
    except Exception as e:
        raise e
