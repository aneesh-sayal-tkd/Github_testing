# !/usr/bin/python
# -*- coding: utf-8 -*-
# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of
# this source code package.

"""Custom Operator to Trigger IDMC Operator"""

__author__ = 'Takeda'

# ####################################################Module Information################################################
#  Module Name         :   TriggerDatabricksRun.py
#  Purpose             :   Custom Operator create run python script, SQL script,create a new SQL warehouse
#  Input Parameters    :   pat_token_secret_name, region_name, databricks_cnt_id, action, parameter_file_name 
#  Output Value        :
#  Pre-requisites      :
#  Last changed on     :   18th December 2023
#  Last changed by     :   Mehul Singhal
#  Reason for change   :
# ######################################################################################################################

# Library and external modules declaration
from airflow.models.baseoperator import BaseOperator
# from airflow.providers.databricks.operators.databricks import DatabricksSqlSensor 
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
import boto3
import xmltodict
from urllib.parse import urlparse
from datetime import datetime
import time
from time import sleep
import requests
import json
import re
import traceback
import logging

class TriggerIDMCMappingTask(BaseOperator):
    """
    Class to create IDMC session, trigger mapping task and fetch the output of a task.
    """
    template_fields = BaseOperator.template_fields + ('pat_token_secret_name', 'region_name','databricks_cnt_id','action','parameter_file_path')
    ui_color = '#FF7900'

    def __init__(self, databricks_cnt_id,action,parameter_file_path, *args,pat_token_secret_name = None,region_name=None, **kwargs):
        super().__init__(**kwargs)
        self.pat_token_secret_name = pat_token_secret_name
        self.region_name = region_name
        self.databricks_cnt_id = databricks_cnt_id
        self.action = action
        self.parameter_file_path = parameter_file_path
        self.task_id = kwargs.get('task_id')
        self.session = requests.Session()

    def execute(self, context):
        """
        Main function to execute operator
        """
        try:
            logging.info("Process Started to Perform Databricks Task")
            logging.info("Fetching Secret from AWS Secret Manager")
            logging.info("Secret Name: {}".format(self.pat_token_secret_name))
            logging.info("Region Name: {}".format(self.region_name))
            logging.info("Task ID: {}".format(self.task_id))
            if self.pat_token_secret_name is not None and self.region_name is not None:
                api_token = self.get_secret()
                self.session.headers.update({'Authorization': f'Bearer {api_token}'})
                self.session.headers.update({'Content-Type': 'application/json'})
            logging.info("Databricks Connection ID: {}".format(self.databricks_cnt_id))
            logging.info("Action: {}".format(self.action))
            logging.info("Parameter File Name: {}".format(self.parameter_file_path))
            param_file_output = self.read_param_file()
            logging.info("Parameter File Output: {}".format(param_file_output))
            if self.action == "create_run_python_script":
                logging.info("Process Started to create run python script")
                python_script = DatabricksSubmitRunOperator(
                    task_id=self.task_id, #Task ID - Name of the Task
                    databricks_conn_id=self.databricks_cnt_id,
                    spark_python_task = param_file_output["spark_python_json"],
                    # new_cluster = f"""{{{{task_instance.xcom_pull(task_ids='read_raw_to_lake_param_file', key='raw_to_lake_databricks_json')}}}}""",
                    # timeout_seconds = f"""{{{{task_instance.xcom_pull(task_ids='read_raw_to_lake_param_file', key='raw_to_lake_timeout_seconds')}}}}""",
                    existing_cluster_id = param_file_output["existing_cluster_id"],
                    run_name = self.task_id)
                logging.info("Process to run a python script in databricks ran successfully")
                logging.info("Python Script: {}".format(python_script))
            return python_script
        except Exception as exception:
            logging.error("Error occurred while triggering IDMC Mapping TaskError: {}".format(exception))
            raise exception
       
    def read_param_file(self):
        try:
            logging.info("Reading the parameter file")
            s3 = boto3.client('s3')
            logging.info("step_name:"+self.task_id)
            logging.info("s3_file_path:"+self.parameter_file_path)
            url = urlparse(self.parameter_file_path)
            bucket = url.netloc
            prefix = url.path.lstrip('/').rstrip('/')
            logging.info("The bucket name is '{0}'".format(bucket))
            logging.info("The file path inside s3 bucket is '{0}'".format(prefix))
            response = s3.get_object(Bucket=bucket, Key=prefix)
            xml_content = response['Body'].read().decode('utf-8')
            xml_data = xmltodict.parse(xml_content)
            # Load JSON data
            logging.info("The XML data is : {0}".format(xml_data))
            logging.info("The parameter file is read successfully")
            xml_list = xml_data["root"]["project"]["mapping"]["parameter"]
            json_data = {}
            for element in xml_list:
                json_data[element["@name"]] = element["#text"]
            if("timeout_seconds" not in json_data.keys()):
                json_data["timeout_seconds"] = "120"
            logging.info("The json data is : {0}".format(json_data))
            existing_cluster_id = None
            if "existing_cluster_id" in json_data.keys():
                existing_cluster_id = json_data["existing_cluster_id"]
            spark_python_json = {}
            databricks_cluster_json = {}
            spark_python_json["python_file"] = json_data["run_script"]
            parameter_list = []
            parameter_list.append(json_data["s3_bucket"])
            parameter_list.append(json_data["s3_file_key"])
            parameter_list.append(json_data["secret_name"])
            parameter_list.append(json_data["region_name"])
            parameter_list.append(json_data["script_params"])
            spark_python_json["parameters"] = parameter_list
            logging.info("The spark_python_json is : {0}".format(spark_python_json))
            if existing_cluster_id is None:
                log_file_path = json_data["log_file_path"]
                region = json_data["region_name"]
                dbfs_json = {"s3":{"destination":log_file_path,"region":region}}
                aws_attribute_json = {}
                aws_attribute_json["instance_profile_arn"] = json_data["iam_profile"]
                # tags_json = {"app":json_data["app"],"project_id":json_data["project_id"],"application_owner":json_data["application_owner"]}
                tags_json = {"app":"ARIBA","project_id":"CDP","application_owner":"Takeda"}
                databricks_cluster_json["spark_version"] = json_data["spark_vers"]
                databricks_cluster_json["node_type_id"] = json_data["machine_size"]
                databricks_cluster_json["custom_tags"] = tags_json
                databricks_cluster_json["aws_attributes"] = aws_attribute_json
                policy_id = json_data["policy_id"].split(",")[0]
                policy_name = json_data["policy_id"].split(",")[1]
                if ("autoscale" in policy_name.lower()): 
                    autoscale_json = {}
                    autoscale_json["min_workers"] = json_data["min_workers"]
                    autoscale_json["max_workers"] = json_data["max_workers"]
                    databricks_cluster_json["autoscale"] = autoscale_json
                else:
                    databricks_cluster_json["num_workers"] = json_data["no_of_worker"]
                if "instance_pool_id" in json_data.keys():
                    databricks_cluster_json["instance_pool_id"] = json_data["instance_pool_id"]
                databricks_cluster_json["policy_id"] = policy_id
                databricks_cluster_json["cluster_log_conf"] = dbfs_json
                logging.info("The databricks_cluster_json is : {0}".format(databricks_cluster_json))
                logging.info("The dbfs_json is : {0}".format(dbfs_json))
                logging.info("The aws_attribute_json is : {0}".format(aws_attribute_json))
                logging.info("The tags_json is : {0}".format(tags_json))
            final_json = {}
            final_json["spark_python_json"] = spark_python_json
            final_json["timeout_seconds"] = json_data["timeout_seconds"]
            final_json["existing_cluster_id"] = existing_cluster_id
            final_json["databricks_cluster_json"] = databricks_cluster_json
            final_json["json_data"] = json_data
        except Exception as e:
            logging.error("Error in reading the parameter file: {0}".format(e))
            raise e 
        
    def get_secret(self):
        """
        Purpose: This fetches the secret details and decrypts them.
        Input: Input dict as dictionary having details to fetch secret
        Output: credentials from Secrets Manager.
        """
        MAX_RETRY_COUNT = 5
        while True:
            try:
                logging.info("Fetching Secret from AWS Secret Manager")
                # Create a Secrets Manager client
                session = boto3.session.Session()
                client = session.client(
                    service_name='secretsmanager',
                    region_name=self.region_name
                )
                logging.info(
                    "Fetching the details for the secret name %s",
                    self.secret_name)
                get_secret_value_response = client.get_secret_value(
                    SecretId=self.secret_name
                )
                logging.info(
                    "Fetched the Encrypted Secret from Secrets Manager for %s",
                    self.secret_name)

                if 'SecretString' in get_secret_value_response:
                    secret = get_secret_value_response['SecretString']
                    logging.info("Decrypted the Secret")
                secret_value = json.loads(secret)
                return secret_value

            except Exception as error:
                MAX_RETRY_COUNT -= 1
                if MAX_RETRY_COUNT != 0:
                    time.sleep(2)
                    continue
                raise Exception("Unable to fetch secrets."+"\n"+str(error))

    
    def call_api(self,URL:str, method:str='GET', params=None, data=None)->str:
        """
        A common function responsible for making API calls 
        for only GET and POST operations. 
        Default timeout seconds = 5

        argument:
            endpoint: API endpoint
            method: type of API call
            params: parameters for GET request
            data: for POST request
        return:
            response.text: result of the API call
        """
        try:
            if method == 'GET':
                response = self.session.get(URL,timeout=10)
            elif method == 'POST':
                response = self.session.post(URL, json=data, timeout=10)
            elif method == 'DELETE':
                response = self.session.delete(URL, timeout=10)
            else:
                raise ValueError(f"Invalid HTTP method: {method}")
            if response.ok:
                return response.text
            else:
                raise Exception(f"API request failed with status code {response.status_code}: {response.text}")
            return response
        except Exception as exception:
            logging.error("Error occurred while calling an API.Error: {}".format(exception))
            raise exception
        
    