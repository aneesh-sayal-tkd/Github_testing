##This is the file for saving the HTML for the notification email

SUCCESS_NOTIFICATION_HTML_FILE = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>title</title>
    </head>
    <body data-feedly-mini="yes">
        <p></p>
        <p></p>
        <!-- [if !mso]><!-->
        <p></p>
        <!--<![endif]-->
        <p></p>
        <!-- [if mso]>
            <body class="mso">
            <![endif]-->
        <p></p>
        <!-- [if !mso]><!-->
        <p></p>
        <!--<![endif]-->
        <p style="font-style: normal; font-weight: 400; margin-bottom: 0; margin-top: 16px; font-size: 15px; line-height: 24px; font-family: 'Open Sans', sans-serif; color: #60666d;">Team,</p>
        <p style="font-style: normal; font-weight: 400; margin-bottom: 0; margin-top: 16px; font-size: 15px; line-height: 24px; font-family: 'Open Sans', sans-serif; color: #60666d;">
            Below mentioned is the status of the Pipeline:$$dag_name$$
        </p>
        <div class="wrapper" style="display: table; table-layout: fixed; width: 100%; min-width: 620px; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; background-color: #f5f7fa; text-align: center;">
            <table summary="Big Data POD" class="header centered" style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto; width: 600px;">
                <th scope="row"></th>
                <tbody>
                <tr>
                    <td style="padding: 0; vertical-align: top;">
                        <table summary="Big Data POD" class="preheader" style="border-collapse: collapse; border-spacing: 0;" align="right">
                            <th scope="row"></th>
                            <tbody>
                            <tr>
                                <td class="emb-logo-padding-box" style="vertical-align: top; padding: 24px 0; text-align: right; width: 280px; letter-spacing: 0.01em; line-height: 17px; font-weight: 400; font-size: 11px;">
                                    <div class="spacer" style="font-size: 1px; line-height: 2px; width: 100%;">&nbsp;</div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
            <table summary="Big Data POD" class="centered" style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto;">
                <th scope="row"></th>
                <tbody>
                <tr>
                    <td style="padding: 0; vertical-align: top;">
                        <table
                            summary="Big Data POD"
                            class="one-col"
                            style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto; width: 900px; background-color: #ffffff; table-layout: fixed;"
                            emb-background-style=""
                            >
                            <th scope="row"></th>
                            <tbody>
                            <tr>
                                <td class="column" style="padding: 0; vertical-align: top; text-align: left;">
                                    <div>
                                        <div class="column-top" style="font-size: 32px; line-height: 32px; transition-timing-function: cubic-bezier(0, 0, 0.2, 1); transition-duration: 150ms; transition-property: all;">&nbsp;</div>
                                    </div>
                                    <table summary="Big Data POD" class="contents" style="border-collapse: collapse; border-spacing: 0; table-layout: fixed; width: 100%;">
                                        <th scope="row"></th>
                                        <tbody>
                                        <tr>
                                            <td class="padded" style="vertical-align: top; padding: 0 32px; word-break: normal; word-wrap: normal;">
                                                <h2
                                                    style="
                                                    font-style: normal;
                                                    font-weight: bold;
                                                    margin-bottom: 0;
                                                    margin-top: 0;
                                                    font-size: 24px;
                                                    line-height: 32px;
                                                    font-family: 'Open Sans', sans-serif;
                                                    color: #46c744;
                                                    text-align: center;
                                                    "
                                                    >
                                                    Pipeline Execution Status
                                                </h2>
                                                <h2
                                                    style="
                                                    font-style: normal;
                                                    font-weight: bold;
                                                    margin-bottom: 0;
                                                    margin-top: 0;
                                                    font-size: 24px;
                                                    line-height: 32px;
                                                    font-family: 'Open Sans', sans-serif;
                                                    color: #46c744;
                                                    text-align: center;
                                                    "
                                                    >
                                                    &nbsp;
                                                </h2>
                                                <h3 style="font-style: normal; font-weight: 400; margin-bottom: 0; margin-top: 0; font-size: 18px; line-height: 24px; font-family: 'Open Sans', sans-serif; color: #3b3e42;">
                                                    <strong style="font-weight: bold;">Execution Details</strong>
                                                </h3>
                                                <ul
                                                    style="
                                                    font-style: normal;
                                                    font-weight: 400;
                                                    padding-left: 0;
                                                    margin-bottom: 24px;
                                                    margin-top: 24px;
                                                    font-size: 15px;
                                                    line-height: 24px;
                                                    margin-left: 20px;
                                                    font-family: 'Open Sans', sans-serif;
                                                    color: #60666d;
                                                    "
                                                    >
                                                    <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Pipeline ID: $$dag_id$$</li>
                                                    <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Pipeline Run ID: $$run_id$$</li>
                                                    <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Overall Pipeline Status: $$status$$</li>
                                                    <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Execution Date: $$execution_date$$</li>
                                                    <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Pipeline URL: <a href="$$url$$">$$dag_name$$</a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <div class="column-bottom" style="font-size: 32px; line-height: 32px; transition-timing-function: cubic-bezier(0, 0, 0.2, 1); transition-duration: 150ms; transition-property: all;">&nbsp;</div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
            <table summary="Big Data POD" class="footer centered" style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto; width: 100%;">
                <th scope="row"></th>
                <tbody>
                <tr>
                    <td style="padding: 0; vertical-align: top;">&nbsp;</td>
                    <td class="inner" style="padding: 58px 0 29px 0; vertical-align: top; width: 600px;">
                        <table summary="Big Data POD" class="right" style="border-collapse: collapse; border-spacing: 0;" align="right">
                            <th scope="row"></th>
                            <tbody>
                            <tr>
                                <td style="padding: 0; vertical-align: top; color: #b9b9b9; font-size: 12px; line-height: 22px; max-width: 200px; mso-line-height-rule: at-least;">
                                    <div class="sharing"></div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <table summary="Big Data POD" class="left" style="border-collapse: collapse; border-spacing: 0;" align="left">
                            <th scope="row"></th>
                            <tbody>
                            <tr>
                                <td style="padding: 0; vertical-align: top; color: #b9b9b9; font-size: 12px; line-height: 22px; text-align: left; width: 400px;">
                                    <div class="address" style="font-family: 'Open Sans', sans-serif; margin-bottom: 18px;">
                                        <div>This email is auto-generated. Do NOT Reply to this message</div>
                                    </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td style="padding: 0; vertical-align: top;">&nbsp;</td>
                </tr>
                </tbody>
            </table>
        </div>
        <div id="feedly-mini" title="feedly Mini tookit"></div>
    </body>
    </html>"""
    
ERROR_NOTIFICATION_HTML_FILE = """
<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                <title>title</title>
            </head>
            <body data-feedly-mini="yes">
                <p></p>
                <p></p>
                <!-- [if !mso]><!-->
                <p></p>
                <!--<![endif]-->
                <p></p>
                <!-- [if mso]>
                    <body class="mso">
                    <![endif]-->
                <p></p>
                <!-- [if !mso]><!-->
                <p></p>
                <!--<![endif]-->
                <p style="font-style: normal; font-weight: 400; margin-bottom: 0; margin-top: 16px; font-size: 15px; line-height: 24px; font-family: 'Open Sans', sans-serif; color: #60666d;">Team,</p>
                <p style="font-style: normal; font-weight: 400; margin-bottom: 0; margin-top: 16px; font-size: 15px; line-height: 24px; font-family: 'Open Sans', sans-serif; color: #60666d;">
                    Below mentioned is the status of the Pipeline:$$dag_name$$
                </p>
                <div class="wrapper" style="display: table; table-layout: fixed; width: 100%; min-width: 620px; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; background-color: #f5f7fa; text-align: center;">
                    <table summary="Big Data POD" class="header centered" style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto; width: 600px;">
                        <th scope="row"></th>
                        <tbody>
                        <tr>
                            <td style="padding: 0; vertical-align: top;">
                                <table summary="Big Data POD" class="preheader" style="border-collapse: collapse; border-spacing: 0;" align="right">
                                    <th scope="row"></th>
                                    <tbody>
                                    <tr>
                                        <td class="emb-logo-padding-box" style="vertical-align: top; padding: 24px 0; text-align: right; width: 280px; letter-spacing: 0.01em; line-height: 17px; font-weight: 400; font-size: 11px;">
                                            <div class="spacer" style="font-size: 1px; line-height: 2px; width: 100%;">&nbsp;</div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <table summary="Big Data POD" class="centered" style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto;">
                        <th scope="row"></th>
                        <tbody>
                        <tr>
                            <td style="padding: 0; vertical-align: top;">
                                <table
                                    summary="Big Data POD"
                                    class="one-col"
                                    style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto; width: 900px; background-color: #ffffff; table-layout: fixed;"
                                    emb-background-style=""
                                    >
                                    <th scope="row"></th>
                                    <tbody>
                                    <tr>
                                        <td class="column" style="padding: 0; vertical-align: top; text-align: left;">
                                            <div>
                                                <div class="column-top" style="font-size: 32px; line-height: 32px; transition-timing-function: cubic-bezier(0, 0, 0.2, 1); transition-duration: 150ms; transition-property: all;">&nbsp;</div>
                                            </div>
                                            <table summary="Big Data POD" class="contents" style="border-collapse: collapse; border-spacing: 0; table-layout: fixed; width: 100%;">
                                                <th scope="row"></th>
                                                <tbody>
                                                <tr>
                                                    <td class="padded" style="vertical-align: top; padding: 0 32px; word-break: normal; word-wrap: normal;">
                                                        <h2
                                                            style="
                                                            font-style: normal;
                                                            font-weight: bold;
                                                            margin-bottom: 0;
                                                            margin-top: 0;
                                                            font-size: 24px;
                                                            line-height: 32px;
                                                            font-family: 'Open Sans', sans-serif;
                                                            color: #FF5733 ;
                                                            text-align: center;
                                                            "
                                                            >
                                                            Pipeline Execution Status
                                                        </h2>
                                                        <h2
                                                            style="
                                                            font-style: normal;
                                                            font-weight: bold;
                                                            margin-bottom: 0;
                                                            margin-top: 0;
                                                            font-size: 24px;
                                                            line-height: 32px;
                                                            font-family: 'Open Sans', sans-serif;
                                                            color: #46c744;
                                                            text-align: center;
                                                            "
                                                            >
                                                            &nbsp;
                                                        </h2>
                                                        <h3 style="font-style: normal; font-weight: 400; margin-bottom: 0; margin-top: 0; font-size: 18px; line-height: 24px; font-family: 'Open Sans', sans-serif; color: #3b3e42;">
                                                            <strong style="font-weight: bold;">Execution Details</strong>
                                                        </h3>
                                                        <ul
                                                            style="
                                                            font-style: normal;
                                                            font-weight: 400;
                                                            padding-left: 0;
                                                            margin-bottom: 24px;
                                                            margin-top: 24px;
                                                            font-size: 15px;
                                                            line-height: 24px;
                                                            margin-left: 20px;
                                                            font-family: 'Open Sans', sans-serif;
                                                            color: #60666d;
                                                            "
                                                            >
                                                            <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Pipeline ID: $$dag_id$$</li>
                                                            <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Pipeline Run ID: $$run_id$$</li>
                                                            <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Overall Pipeline Status: $$status$$</li>
                                                            <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Error Message: $$error_message$$</li>
                                                            
                                                            <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Execution Date: $$execution_date$$</li>
                                                            <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Pipeline URL: <a href="$$pipeline_url$$">$$dag_name$$</a></li>
                                                            <li style="padding-left: 2px; margin-bottom: 0; margin-top: 0;">Cloudwatch URL: <a href="$$log_url$$">Click to Watch Logs </a></li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                            <div class="column-bottom" style="font-size: 32px; line-height: 32px; transition-timing-function: cubic-bezier(0, 0, 0.2, 1); transition-duration: 150ms; transition-property: all;">&nbsp;</div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <table summary="Big Data POD" class="footer centered" style="border-collapse: collapse; border-spacing: 0; margin-left: auto; margin-right: auto; width: 100%;">
                        <th scope="row"></th>
                        <tbody>
                        <tr>
                            <td style="padding: 0; vertical-align: top;">&nbsp;</td>
                            <td class="inner" style="padding: 58px 0 29px 0; vertical-align: top; width: 600px;">
                                <table summary="Big Data POD" class="right" style="border-collapse: collapse; border-spacing: 0;" align="right">
                                    <th scope="row"></th>
                                    <tbody>
                                    <tr>
                                        <td style="padding: 0; vertical-align: top; color: #b9b9b9; font-size: 12px; line-height: 22px; max-width: 200px; mso-line-height-rule: at-least;">
                                            <div class="sharing"></div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                                <table summary="Big Data POD" class="left" style="border-collapse: collapse; border-spacing: 0;" align="left">
                                    <th scope="row"></th>
                                    <tbody>
                                    <tr>
                                        <td style="padding: 0; vertical-align: top; color: #b9b9b9; font-size: 12px; line-height: 22px; text-align: left; width: 400px;">
                                            <div class="address" style="font-family: 'Open Sans', sans-serif; margin-bottom: 18px;">
                                                <div>This email is auto-generated. Do NOT Reply to this message</div>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td style="padding: 0; vertical-align: top;">&nbsp;</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div id="feedly-mini" title="feedly Mini tookit"></div>
            </body>
            </html>
"""
    
