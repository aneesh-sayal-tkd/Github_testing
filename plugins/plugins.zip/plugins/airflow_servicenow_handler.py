import logging
import requests
import html
import time
from airflow.configuration import conf
from airflow.hooks.base import BaseHook

logger = logging.getLogger(__name__)

def notify_api_on_failure(context, payload):
    """
    Sends a failure notification to an API when a DAG fails.

    Args:
        context (dict): Airflow context dictionary providing runtime metadata.
        payload (dict): Custom payload parameters.
    """
    logger.info("Task Failed. Initiating Payload creation...")

    try:
        # snow_conn_id = "your_snow_conn_id_here"
        # snow_connection = BaseHook.get_connection(snow_conn_id)
        # base_url = snow_connection.host
        # api_url = f"{base_url}/services/createsnowincident/tidal-api"
        # token = snow_connection.password
        # headers = {
        #     "x-api-key": token,
        #     "Content-Type": "application/json"
        # }

        # Extract context data safely
        dag = context.get('dag')
        if not dag:
            logger.error("Missing 'dag' in context.")
            return

        dag_id = dag.dag_id
        dag_owner = getattr(dag, 'owner', 'unknown')
        task = context.get('task')
        task_id = getattr(task, 'task_id', 'unknown')
        run_id = context.get('run_id', 'unknown')
        execution_date = context.get('execution_date')
        exception_message = str(context.get('exception', 'No exception information available'))

        extracted_date = execution_date.strftime("%Y-%m-%d") if execution_date else "unknown"
        airflow_base_url = conf.get('webserver', 'base_url')
        dag_url = f"{airflow_base_url}/dags/{dag_id}/grid"

        if payload:
            payload["short_description"] = f"\{dag_id}_{extracted_date}\\Run_Id: {run_id} has Failed"
            long_description = (
                f"DagRun {dag_id}_{extracted_date} with Run_Id: {run_id} failed at Task: {task_id} "
                f"with Exception: {exception_message}.\nDAG Url: {dag_url} .\nDAG Owner: {dag_owner}"
            )
            payload["long_description"] = long_description[:4000]

            for key in payload:
                if isinstance(payload[key], str):
                    payload[key] = html.escape(payload[key])

            logger.info(f"Generated Payload Successfully..!!\nPayload: {payload}")
        else:
            logger.warning("No payload provided to notify API.")
            return

        # Retry logic for sending API request (currently disabled)
        # for attempt in range(3):
        #     try:
        #         response = requests.post(api_url, json=payload, headers=headers, timeout=10, verify=False)
        #         response.raise_for_status()
        #         if response.status_code == 200:
        #             logger.info("Snow Incident created successfully!")
        #             break
        #         else:
        #             logger.warning(f"Unexpected response status code: {response.status_code}")
        #     except requests.exceptions.RequestException as e:
        #         logger.error(f"Attempt {attempt + 1}: Failed to notify API: {e}")
        #         if attempt < 2:
        #             time.sleep(2)

    except Exception as e:
        logger.exception(f"Error in notify_api_on_failure: {e}")
