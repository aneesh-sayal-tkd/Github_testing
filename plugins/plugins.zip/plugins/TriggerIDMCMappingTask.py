# !/usr/bin/python
# -*- coding: utf-8 -*-
# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of
# this source code package.

"""Custom Operator to Trigger IDMC Operator"""

__author__ = 'Takeda'

# ####################################################Module Information################################################
#  Module Name         :   TriggerIDMCMappingTask.py
#  Purpose             :   Custom Operator create iics session, trigger mapping task and fetch the output of a task.
#  Input Parameters    :   secret_name, region_name
#  Output Value        :
#  Pre-requisites      :
#  Last changed on     :   4th Decemeber 2023
#  Last changed by     :   Mehul Singhal
#  Reason for change   :
# ######################################################################################################################

# Library and external modules declaration
from airflow.models.baseoperator import BaseOperator
import boto3
from datetime import datetime
import time
from time import sleep
import requests
import json
import re
import traceback
import logging

class TriggerIDMCMappingTask(BaseOperator):
    """
    Class to create IDMC session, trigger mapping task and fetch the output of a task.
    """
    template_fields = BaseOperator.template_fields + ('secret_name', 'region_name','iics_mapping_task_name')
    ui_color = '#FF7900'

    def __init__(self, secret_name,region_name,iics_mapping_task_name, *args, **kwargs):
        super().__init__(**kwargs)
        self.secret_name = secret_name
        self.region_name = region_name
        self.iics_mapping_task_name = iics_mapping_task_name
        self.HEADER = { 'Accept': 'application/json',
        'Content-Type': 'application/json' }

    def execute(self, context):
        """
        Main function to execute operator
        """
        try:
            logging.info("Process Started to Trigger IDMC Mapping Task")
            logging.info("Fetching Secret from AWS Secret Manager")
            logging.info("Secret Name: {}".format(self.secret_name))
            logging.info("Region Name: {}".format(self.region_name))
            logging.info("Process Started to create IICS session")
            server_url = self.create_iics_session()
            mapping_id = self.execute_mapping_task(server_url)
            logging.info("Mapping Task ID: {}".format(mapping_id))
            mpt_status , src_count , tgt_count , error_msg = self.track_mapping_task(server_url,mapping_id)
            logging.info("Status of Mapping Task: {}".format(mpt_status))
            if mpt_status == 'COMPLETED':
                logging.info("\nMapping Task finished successfully")
            else:
                logging.info("Mapping Task failed with error. Pls check the error logs in Cloudwatch.")
            return_dict = {}
            return_dict["source_count"]= src_count
            return_dict["target_count"]= tgt_count
            logging.info("Source Count: {}".format(str(src_count)))
            logging.info("Target Count: {}".format(str(tgt_count)))
            return return_dict
        except Exception as exception:
            logging.error("Error occurred while triggering IDMC Mapping TaskError: {}".format(exception))
            raise exception
        
    def create_iics_session(self):
        """
        Responsible for authentication and 
        adding base URL and session ID in header.

        argument:
            username: username for authentication
            password: password for authentication
        return:
            api_url: new url where API request 
            need to be made.
        """
        try:
            logging.info("Process Started to Create IICS Session")
            CONFIG = self.get_secret()
            if 'base' not in CONFIG or 'username' not in CONFIG or\
                'password' not in CONFIG:
                raise ValueError("Error Occured while fetching Key not found in secret")
            logging.info("Secrets Fetched Successfully")
            logging.info("Secret Values: {}".format(CONFIG))
            logging.info("Creating IICS Session")
            api_call_url = CONFIG['base'] + "user/login"
            login_response = self.call_api(api_call_url, "POST", data= {"username":CONFIG["username"], "password":CONFIG["password"]})
            login_response = json.loads(login_response)
            icSessionId = login_response.get("icSessionId",None)
            serverUrl = login_response.get("serverUrl",None)
            logging.info(CONFIG)
            if icSessionId:
                self.HEADER["icSessionId"] = icSessionId
            else:
                raise ValueError("icSessionId not found.")
            return serverUrl
        except Exception as exception:
            logging.error("Error occurred while creating IICS sessionError: {}".format(exception))
            raise exception
        
    def get_secret(self):
        """
        Purpose: This fetches the secret details and decrypts them.
        Input: Input dict as dictionary having details to fetch secret
        Output: credentials from Secrets Manager.
        """
        MAX_RETRY_COUNT = 5
        while True:
            try:
                logging.info("Fetching Secret from AWS Secret Manager")
                # Create a Secrets Manager client
                session = boto3.session.Session()
                client = session.client(
                    service_name='secretsmanager',
                    region_name=self.region_name
                )
                logging.info(
                    "Fetching the details for the secret name %s",
                    self.secret_name)
                get_secret_value_response = client.get_secret_value(
                    SecretId=self.secret_name
                )
                logging.info(
                    "Fetched the Encrypted Secret from Secrets Manager for %s",
                    self.secret_name)

                if 'SecretString' in get_secret_value_response:
                    secret = get_secret_value_response['SecretString']
                    logging.info("Decrypted the Secret")
                secret_value = json.loads(secret)
                return secret_value

            except Exception as error:
                MAX_RETRY_COUNT -= 1
                if MAX_RETRY_COUNT != 0:
                    time.sleep(2)
                    continue
                raise Exception("Unable to fetch secrets."+"\n"+str(error))

    
    def call_api(self,URL:str, method:str='GET', params=None, data=None)->str:
        """
        A common function responsible for making API calls 
        for only GET and POST operations. 
        Default timeout seconds = 5

        argument:
            endpoint: API endpoint
            method: type of API call
            params: parameters for GET request
            data: for POST request
        return:
            response.text: result of the API call
        """
        try:
            if method == 'GET':
                response = requests.get(URL, headers=self.HEADER, params=params, timeout=10)
            elif method == 'POST':
                response = requests.post(URL, headers=self.HEADER, json=data, timeout=10)
            else:
                raise ValueError(f"Invalid HTTP method: {method}")
            if response.ok:
                return response.text
            else:
                raise Exception(f"API request failed with status code {response.status_code}: {response.text}")
            return response
        except Exception as exception:
            logging.error("Error occurred while calling an API.Error: {}".format(exception))
            raise exception
        
    def execute_mapping_task(self,server_url):
        try:
            logging.info("Process Started to Trigger Mapping Task")
            logging.info("Server URL: {}".format(server_url))
            logging.info("Mapping Task Name: {}".format(self.iics_mapping_task_name))
            logging.info("Fetching Mapping ID for Mapping Task")
            api_url = server_url.rstrip('/') + "/api/v2/mttask/name/"+str(self.iics_mapping_task_name).replace(" ","%20")
            resp_mapping_id = self.call_api(api_url)
            mapping_id = json.loads(resp_mapping_id)["id"]
            logging.info("Mapping ID: {}".format(mapping_id))
            api_url = server_url.rstrip('/') + "/api/v2/job"
            payload = {"@type": "job", "taskName": self.iics_mapping_task_name , "taskType": "MTT"}
            resp = self.call_api(api_url, "POST", data = payload )
            logging.info("Mapping Task Triggered Successfully")
            return mapping_id
        except Exception as exception:
            logging.error("Error occurred while triggering IICS Mapping Task.Error: {}".format(exception))
            raise exception
        
    def track_mapping_task(self,server_url,mapping_id):
        '''
        Function makes the API calls to track the running status of mapping task.
        
        This functions makes the API calls to track the running status of mapping task on Informatica cloud.
        API calls are made in every 3 seconds to check the running status.
        If the response fetches no result then the other function is called which check the final status.
        '''
        try:
            logging.info("Process Started to Track Mapping Task")
            logging.info("Server URL: {}".format(server_url))
            logging.info("Mapping ID: {}".format(mapping_id))
            api_url = server_url + "/api/v2/activity/activityMonitor?"
            payload = {}
            status = True
            while status == True:
                sleep(3)
                resp = self.call_api(api_url, "GET", data = payload)   ##Making the API call to the monitor the map task
                response = json.loads(resp)

                if("statusCode" in response and response["statusCode"] == 401 and response["description"]== "Authentication failure."):
                    self.create_iics_session()
                    resp = self.track_mapping_task(server_url , mapping_id)  ## check for any Authentication failure
                
                
                for i in range(0,len(response)):
                    if response[i]["taskId"] == mapping_id:
                        if response[i]["executionState"] in ("INITIALIZED", "RUNNING", "QUEUED"):
                            logging.info(f'{response[i]["executionState"]}.......... ')
                            status = True
                            break
                        else:
                            logging.info(f'{response[i]["executionState"]}.......... ')
                            break
                    elif i == len(response) - 1:
                        logging.info(f'[{mapping_id}] Mapping task id not available in the response. Please check the completion or failure status')
                        sleep(10)
                        status = False
                        break
                    else:
                        pass
            state = self.check_mapping_task_status(server_url , mapping_id, 0)
            return state
        except Exception as exception:
            logging.error("Error occurred while tracking IICS Mapping Task.Error: {}".format(exception))
            raise exception
    
    def check_mapping_task_status(self,server_url,mapping_id,count):
        '''
        This function makes API calls to check the final status of mapping task.
        
        This function makes API calls the status of mapping task when the running task API doesn't fetches any results.
        This function fetches the final status, either completed or failed. 
        '''
        try:
            api_url = server_url + f"/api/v2/activity/activityLog?taskId={mapping_id}"
            payload = {}
            response = self.call_api(api_url, "GET", data = payload)   ### Makes the API call to fetch the final status

            response = json.loads(response)
        
            if("statusCode" in response and response["statusCode"] == 401 and response["description"]== "Authentication failure."):
                self.create_iics_session()
                resp = self.check_mapping_task_status(server_url , mapping_id, count)  ## check for any Authentication failure
            
            logging.info(f" Mapping task final status {response}")

            source_count = response[0]["successSourceRows"]
            target_count = response[0]["successTargetRows"]
            error_msg    = response[0]["entries"][0]["errorMsg"]
            # FIXME: If message contains SDKS_38502 Plug-in #606801...failed in method [deinit], mark as COMPLETED
        
        
            while(count<3):
                
                count += 1
            
                if len(response) == 0:
                    self.check_mapping_task_status(server_url=server_url , mapping_id=mapping_id, count=count)
                
                else:
                    if "errorMsg" in response[0]:
                        result = re.search(r'SDKS_38502 Plug-in #606801.* failed in method', response[0]["errorMsg"])
                        if result:
                            return "COMPLETED"
                    if response[0]["state"] == 1:
                        state = "COMPLETED"
                    else:
                        state = "FAILED"
                    return state , source_count, target_count, error_msg
            
            logging.error(f'[{mapping_id}] Mapping task id not available in the final status even retrying thrice. Please contact the Ops team.')
            logging.error(str(f"Find thre  Traceback (if any): "+ traceback.format_exc()) )
            raise Exception ("Mapping task response empty. Conatct Ops team")
        except Exception as exception:
            logging.error("Error occurred while checking IICS Mapping Task Status.Error: {}".format(exception))
            raise exception
            
        
  
        
        

